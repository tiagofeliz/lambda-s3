// dependencies
const FormData = require('form-data');
const ASYNC = require('async');
const AWS = require('aws-sdk');
const UTIL = require('util');
const AXIOS = require('axios');

const Logger = require('./Logger')

const BEARER = "Bearer ";

var token = "H4sIAAAAAAAAAIVU2ZKjOBD8op4AYTfNozkNDcKAkJBeOjhsc7rpBoPh61d4ZnZ2IzZiHwh0VWVmKUvnxSkzK6%2F8yoni1RZhZQ%2F2Ldznmv1qN32CNUf5cV4cMQd4ScC%2BzEi8Ha4ogd8ZYF1KYBtY5VRYYpnfgjsFyugD2ELdAFCHrUtYB2s6QsvYQU3YM2SILgk7itTGRxR4wNj52gYK60xSW7vuM%2FvmtJQElas5Ut61Aoucgo8%2FMykYiwS2ecXJ1bbo68HOq2M56Mw6BUrHurZmkRozYo7%2Baixw2c1ufbh7aHj4Or17dbBza0Pyqp3oo%2FF%2FNDglBePEOtZTEMseCkS4elzTYfHRYfb0Ucs7c03J%2FPeetzYrrJ97XhgXKjIVE7Whg81GDpKwL7o3OTbDS9DaMsbQ8AHnr8MSAiq4CNasDnidzJpGYkmJIbmo2UNgPyDhuChefX14QD2WvDUXnlzqfHnqW3PJ15vVR1yb7u1gHfO65LK3nUe5wMecsz37%2BkH0xWJMRXg7HxsxWls%2FFkwjFJxPKjpf6eqcWIMfNHFuWP9TX%2B%2BJnXMOAde46RsESGLgoQb4miBSxEoXebNH6OjrvO6RWDGLCh5irY%2FiB12pXBwdkaFRDRvmIKNVsYENfx0e3hoL%2FC8%2Fv4X7oMO7zXwcU4J6IHD%2Bi6fNFU2wkFrKkvI6ssSr%2FHao8qMzsSOuC1OZCrDffLH5aOT8hYjs18Iyh8wS2%2BwWrnbFc5BwTMlu85XAiDhnlikwrIyUjL9jxfyoTvktvGTEvFNS%2FFnn2IUVb7FlYeE749%2Bv%2BZRbeKGcVwb2T5ynR1ul4vnr9KmJiZn1uORSuMWOjOyF7RzH6DNN%2FMNlu3dp88k23uJajsFzcz8mUtEzq2iLrVe6sM8ldaBJe%2FmHpoURPNJOGXLwts1RbJhRJDzMRMQoxPa2Bjh2w0g4PXU15Qmbqko2rBteC2IuKVE4TzxnkvOTw83p%2Bc1P%2BVMHnDjPiu%2BVjNfjvzVsMeqSgVAsfp2hEvx3zi1Poi70N49NZ6dsfbZx%2FPXWOIvdCnyvF9Jo63djz%2FRmoXXZuYTuKGp4r8R73iuVh2zRRYHgW8HqE2OmwF68nzhDSvg9mUrPtgetiwHtwpYCWLkoXyG6jlDnPbbwHMCbuYcfFBgrRYet5x783VF%2BuP33oF%2BPuRyaddSLDKR2X8Yv33sa0um6m6%2F3XX%2BO5by5HngjDMfxjmctET%2BmyBk%2BSXg6H2enwq84nqQ30uC2mP1oMppMK5OOaInwklwBU2LzKh6GALPR7z9mWVf75bT%2F%2Fl6%2BXtyD1dlL%2F9bIrussy8dAvr%2F8%2FSkfvLC4BM7nB3wPrUPXOp9f7%2Bhyus%2B4K3ElZJd2xvXjvb029Agu027Yr5F%2B9OxS%2B5DGu5W6r5Wcly%2FnpB06WYULSC8hAXCWj9WpBlk7xh08XHvhY9GpcopT%2B%2FYZnjU3P0vkpSdfZHo1ylYaT%2B%2BTEbxXH%2FT8WAWHXY7qW5JEupJdcCy8dsf378SI7EiUZxyvC6u0mzh%2B3g5%2FAfyRSwJ4BgAA";
var server = "https://api-backoffice.buildstaging.com";
var endpoint = "/backoffice/rest/v1/transfers/upload/itau";

const s3 = new AWS.S3();
var logger = new Logger();
 
exports.handler = function(event, context, callback) {
    
    logger.log("[INFO] Reading options from event:\n", UTIL.inspect(event, {depth: 5}));
    var bucketName = event.Records[0].s3.bucket.name;
    
    var triggerObject = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));

    var targetObject = triggerObject.replace("received", "uploaded-receive-files")

    logger.log(`[INFO] Bucket source: ${bucketName}`)
    logger.log(`[INFO] Trigger object: ${triggerObject}`)
    logger.log(`[INFO] Target object: ${targetObject}`)

    ASYNC.waterfall([
        function download(next) {
            s3.getObject({
                Bucket: bucketName,
                Key: triggerObject
            }, next);
        },
        function upload(response, next) {
            var formData = new FormData(); 
            formData.append('data', response.Body, '');
            AXIOS.post(`${server+endpoint}`, formData, {
                headers: {
                    'Authorization': `${BEARER+token}`,
                    'Content-Type': `multipart/form-data; boundary=${formData._boundary}`
                }
            })
            .then(function (res) {
                logger.log(`[INFO] Request successfully sent.`, res);
                next(null, response.ContentType, response.Body);
            })
            .catch(function (error) {
                logger.log(`[ERROR] Error in request with error: `, error);
            })
        },
        function copy(contentType, data, next) {
            s3.putObject({
                Bucket: bucketName,
                Key: targetObject,
                Body: data,
                ContentType: contentType
            }, next);
        },
        function remove(response, next) {
            s3.deleteObject({
                Bucket: bucketName,
                Key: triggerObject,
            }, next);
        }
    ], function (err) {
        if (err) {
            logger.log(`[ERROR] Error in upload received file with error: `, err);
        } else {
            logger.log("[INFO] File uploaded successfully");
        }
        callback(null, "message");
    });
};